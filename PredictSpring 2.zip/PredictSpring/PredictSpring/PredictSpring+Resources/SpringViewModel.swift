//
//  SpringViewModel.swift
//  PredictSpring
//
//  Created by mounika on 06/10/23.
//

import Combine
import Foundation
import CoreData
import UIKit
import SwiftUI

class SpringViewModel: NSObject, ObservableObject, URLSessionDownloadDelegate {
    
    var input = PassthroughSubject<String, Never>()
    var onReceiveProgress =  PassthroughSubject<Float, Never>()
    var onDownLoadFinished = PassthroughSubject<URL, Never>()

    @Published var filePath: URL?
    
    @Published  var fileContents: [String] = []
    @Published private(set) var downloadProgress: Double = 0.0
    
    private var fileManager: URL?
        
    private let delegate = UIApplication.shared.delegate as? AppDelegate
    private var manager: DataManager?
    private var disposables: Set<AnyCancellable> = .init()
    
    var progress: (() -> ())?
    
    override init() {
        super.init()

        addSubscriptions()
    }
    
    private func addSubscriptions() {
        let context = delegate?.persistentContainer.viewContext
        manager = DataManager(context: context)
        
        fileManager = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: .documentsDirectory, create: true)
           
        input
            .subscribe(on: DispatchQueue(label: "ParseQueue", qos: .background))
            .map({$0})
            .sink { [weak self] in
                guard let self = self, let fileManager = fileManager else {
                    debugPrint("Unable to locate the File Manager")
                    return
                }
                let file = fileManager.appending(path: "predict_spring.csv")
                self.downloadFile(fileID: $0, destinationURL: file)
            }.store(in: &disposables)
        
        $filePath
            .subscribe(on: DispatchQueue(label: "ParseQueue", qos: .background))
            .compactMap({$0})
            .tryMap { try String(contentsOf: $0) }
            .map({$0.components(separatedBy: .newlines)})
            .map({Array($0.dropFirst())})
            .replaceError(with: [])
            .assign(to: \.fileContents, on: self)
            .store(in: &disposables)

        $fileContents
            .subscribe(on: DispatchQueue(label: "ReadContentsQueue", qos: .background))
            .map({$0})
            .sink { lines in
                Task {
                    await self.manager?.prepare(with: lines)
                }
            }.store(in: &disposables)
    }
    
    func downloadFile(fileID: String, destinationURL: URL)  {
        let url = URL(string: "https://drive.google.com/uc?export=download&id=\(fileID)")!
        let downloadQueue = OperationQueue()
        downloadQueue.qualityOfService = .utility
        let sessionConfiguration = URLSessionConfiguration.default
        sessionConfiguration.urlCache = nil
        
        let session = URLSession(configuration: sessionConfiguration, delegate: self, delegateQueue: downloadQueue)
        let task = session.downloadTask(with: url)
        task.resume()
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        if let filePath = filePath, FileManager.default.fileExists(atPath: filePath.absoluteString) {
            try? FileManager.default.removeItem(at: filePath)
        }
        onDownLoadFinished.send(location)
    }
    
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let downloadPr = Float(totalBytesWritten) / Float(totalBytesExpectedToWrite)
        onReceiveProgress.send(downloadPr)
    }
}

extension Array {
    func chunked(into size: Int) -> [[Element]] {
        return stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
}

extension Collection {
    subscript (safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

actor DataManager {
    private var context: NSManagedObjectContext? = nil
    private(set) var batchSize: Int = 1000
    private(set) var batches: [String] = []
    private(set) var isLoading: Bool = false
    
    init?(context: NSManagedObjectContext?) {
        self.context = context
    }
    
    func prepare(with: [String]) async {
        defer {
            isLoading.toggle()
        }
        batches = with
        for eachBatch in batches.chunked(into: batchSize) {
            let filteredBatch = await insertChunked(products: eachBatch)
            try? await save(batch: filteredBatch)
        }
    }
    
    ///
    /// - Parameter products: for loop for the batchsize to increase
    /// - Returns: returns Models
    func insertChunked(products: [String]) async -> NSBatchInsertRequest {
        var index = 0
        let batchInsert = NSBatchInsertRequest(entity: ProductInfo.entity()) { (managedContext: NSManagedObject) -> Bool in
            guard index < products.count else {
                return true
            }
            if let product = managedContext as? ProductInfo {
                let data = products[safe: index]?.components(separatedBy: ",") ?? []
                product.productId = data[safe: 0]
                product.title = data[safe: 1]
                product.listPrice = Double(data[safe: 2] ?? "") ?? 0.0
                product.salePrice = Double(data[safe: 3] ?? "") ?? 0.0
                product.color = data[safe: 4]
                product.size = data[safe: 5]
            }
            index += 1
            return false
        }
        return batchInsert
    }
    // saves the Model in coredata
    func save(batch: NSBatchInsertRequest) async throws {
        guard context != nil else {
            throw NSError(domain: "Unable to find context", code: 22)
        }
        let result = try? context?.execute(batch)
        debugPrint("PREDICTSPRING: \(String(describing: result))")
        try? context?.save()
    }
}

